package com.jumia.validator.enums;

public enum StateEnum {
    VALID, INVALID
}
